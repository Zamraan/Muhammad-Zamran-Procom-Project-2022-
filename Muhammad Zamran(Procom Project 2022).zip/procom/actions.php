<?php
include("db.php");
ob_start();

//board record edit
if (isset($_POST['edit_board'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $desc = $_POST['desc'];
   
    $sql = mysqli_query($db,"UPDATE `board` SET `title`='$name',`description`='$desc' WHERE id='$id'");
    if ($sql) {
       header("location:board.php");
       echo '<script>alert("Record Updated Successfully");</script>';
    }else {
        header("location:board.php");
        echo '<script>alert("Record not Updated");</script>';
    }
}

//edit members record
if (isset($_POST['edit_member'])) {
    $id = $_POST['id'];
    $board = $_POST['board'];
    $user = $_POST['user'];
   
    $sql = mysqli_query($db,"UPDATE `members` SET `boardid`='$board',`userid`='$user' WHERE id='$id'");
    if ($sql) {
       header("location:members.php");
       echo '<script>alert("Record Updated Successfully");</script>';
    }else {
        header("location:members.php");
        echo '<script>alert("Record not Updated");</script>';
    }
}

//edit card records
if (isset($_POST['edit_card'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $desc = $_POST['desc'];
    $level = $_POST['level'];
    $assign = $_POST['assign'];
    $board = $_POST['board'];

    if($_FILES['img']['name'] != ""){
    $img = $_FILES['img']['name'];
    $old = $_FILES['img']['tmp_name'];
    $new = "cardImages/".$img;
    move_uploaded_file($old,$new);
    $sql = mysqli_query($db,"UPDATE `card` SET `title`='$name',`description`='$desc',`image`='$img',`level`='$level',`assign`='$assign',`boardid`='$board' WHERE id='$id'");
    
    }
   
    $sql = mysqli_query($db,"UPDATE `card` SET `title`='$name',`description`='$desc',`level`='$level',`assign`='$assign',`boardid`='$board' WHERE id='$id'");
    if ($sql) {
       header("location:cards.php");
       echo '<script>alert("Record Updated Successfully");</script>';
    }else {
        header("location:cards.php");
        echo '<script>alert("Record not Updated");</script>';
    }
}


ob_flush();
?>