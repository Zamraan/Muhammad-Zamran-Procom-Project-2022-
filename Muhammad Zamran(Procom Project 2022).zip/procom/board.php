<?php
session_start();
ob_start();
if ($_SESSION['name'] == "") {
    header("location:login.php");
}
include("header.php"); 

?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">

        <!-- Insert Data modal -->
<button type="button" class="btn btn-success" data-toggle="modal" data-target="#exampleModal">
  Add New Record
</button>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
   <form action="" method="POST">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"> Add New Record</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <input type="text" name="name" required class="form-control" placeholder="Enter Title..." />
        <br>

        <textarea name="desc" id="" required class="form-control" placeholder="Description..."></textarea>
        
	</div>
      <div class="modal-footer">
	<button type="submit" name="btn" class="btn btn-success">Done</button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </form>
  </div>
</div>
<br>
<br>

        <center><div class="row">
          <div class="col-sm-12">
            <h1 class="m-0 text-dark">Boards List</h1>
          </div><!-- /.col -->
        
        </div></center>

<?php
//Add Record    
if (isset($_POST['btn'])) {
    
    $name = $_POST['name'];
    $desc = $_POST['desc'];
   
    $sql = mysqli_query($db,"INSERT INTO `board` VALUES (null,'$name','$desc')");
    if ($sql) {
        echo '
       <div class="alert alert-success alert-dismissible fade show" role="alert">
  <strong>Record Added Successfully</strong>
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
       ';
    }else {
       echo '
       <div class="alert alert-danger alert-dismissible fade show" role="alert">
  <strong>Record not Added</strong>
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
       ';
    }
}

//Delete record
if (isset($_POST['del'])) {
    
    $id = $_POST['id'];
   
   
    $sql = mysqli_query($db,"DELETE FROM `board` WHERE id = '$id'");
    if ($sql) {
        echo '
       <div class="alert alert-success alert-dismissible fade show" role="alert">
  <strong>Record Deleted Successfully</strong>
  <button type="button" class="close text-white" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
       ';
    }else {
       echo '
       <div class="alert alert-danger alert-dismissible fade show" role="alert">
  <strong>Record not Deleted Successfully</strong>
  <button type="button" class="close text-white" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
       ';
    }
}

?>



      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
      
      <table id="example" class="table table-striped">
          <thead>
              <tr>
                  <th>#</th>
                  <th>Title</th>
                  <th>Descriptions</th>
                  <th>Action</th>
              </tr>
          </thead>

          <tbody>
              <?php
              if (isset($_GET['search'])) {
              $search = $_GET['search'];
              $sql = mysqli_query($db,"SELECT * FROM `board` WHERE CONCAT(`title`, `description`) LIKE '%$search%' ORDER BY id DESC");
              $i = 1;
              foreach($sql as $row){
              ?>
                 <tr>
                     <td><?php echo $i; ?></td>
                     <td><?php echo $row['title'] ?></td>
                     <?php
                        $description = strlen($row['description']) > 150? substr($row['description'],0,50).'...':$row['description'];
                     ?>
                     <td><?php echo $description ?></td>

                     <td>
                     <!-- edit Data modal -->
<button type="button" class="btn btn-success" data-toggle="modal" data-target="#editModal<?php echo $row['id'] ?>">
<span class="fa fa-edit"></span>
</button>

<!-- Modal -->
<div class="modal fade" id="editModal<?php echo $row['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
   <form action="actions.php" method="POST">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"> Update Record</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <input type="hidden" name="id" value="<?php echo $row['id'] ?>">

        <input type="text" name="name" value="<?php echo $row['title'] ?>" required class="form-control" placeholder="Enter Title..." />
        <br>

        <textarea name="desc" id="" required class="form-control" placeholder="Description..."><?php echo $row['description'] ?></textarea>
        
	</div>
      <div class="modal-footer">
	<button type="submit" name="edit_board" class="btn btn-success">Done</button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </form>
  </div>
</div>


                         <!-- Delete modal -->
<button type="button" class="btn btn-danger" data-toggle="modal" data-target="#deleteModal<?php echo $row['id'] ?>">
  <span class="fa fa-trash"></span>
</button>

<!-- Modal -->
<div class="modal fade" id="deleteModal<?php echo $row['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
   <form action="" method="POST">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <input type="hidden" name="id" value="<?php echo $row['id'] ?>" />
        <p>Are you Sure you want to Delete this Record</p>
	</div>
      <div class="modal-footer">
	<button type="submit" name="del" class="btn btn-danger">Delete</button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </form>
  </div>
</div>

                     </td>
                 </tr>
              <?php $i++;}}else{
              $sql = mysqli_query($db,"SELECT * FROM `board` ORDER BY id DESC");
              $i = 1;
              foreach($sql as $row){
              ?>

                     <tr>
                     <td><?php echo $i; ?></td>
                     <td><?php echo $row['title'] ?></td>
                     <?php
                        $description = strlen($row['description']) > 150? substr($row['description'],0,50).'...':$row['description'];
                     ?>
                     <td><?php echo $description ?></td>

                     <td>
                     <!-- edit Data modal -->
<button type="button" class="btn btn-success" data-toggle="modal" data-target="#editModal<?php echo $row['id'] ?>">
<span class="fa fa-edit"></span>
</button>

<!-- Modal -->
<div class="modal fade" id="editModal<?php echo $row['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
   <form action="actions.php" method="POST">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"> Update Record</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <input type="hidden" name="id" value="<?php echo $row['id'] ?>">

        <input type="text" name="name" value="<?php echo $row['title'] ?>" required class="form-control" placeholder="Enter Title..." />
        <br>

        <textarea name="desc" id="" required class="form-control" placeholder="Description..."><?php echo $row['description'] ?></textarea>
        
	</div>
      <div class="modal-footer">
	<button type="submit" name="edit_board" class="btn btn-success">Done</button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </form>
  </div>
</div>


                         <!-- Delete modal -->
<button type="button" class="btn btn-danger" data-toggle="modal" data-target="#deleteModal<?php echo $row['id'] ?>">
  <span class="fa fa-trash"></span>
</button>

<!-- Modal -->
<div class="modal fade" id="deleteModal<?php echo $row['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
   <form action="" method="POST">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <input type="hidden" name="id" value="<?php echo $row['id'] ?>" />
        <p>Are you Sure you want to Delete this Record</p>
	</div>
      <div class="modal-footer">
	<button type="submit" name="del" class="btn btn-danger">Delete</button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </form>
  </div>
</div>

                     </td>
                 </tr>

              <?php $i++;}}?>
          </tbody>
      </table>
      
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php include("footer.php"); ob_flush();?>