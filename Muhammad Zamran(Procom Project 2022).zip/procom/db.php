<?php
$db = mysqli_connect("localhost","root","","procom");
if (!$db) {
    echo "
    <script>
    alert('Database not Connected');
</script>
    ";
}
?>
