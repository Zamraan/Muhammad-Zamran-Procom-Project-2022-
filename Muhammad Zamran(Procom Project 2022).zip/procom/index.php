<?php
session_start();
if ($_SESSION['name'] == "") {
    header("location:login.php");
}
include("header.php"); 
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Dashboard</h1>
          </div><!-- /.col -->
        
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
            <?php
            if(isset($_GET['search'])){
            $search = $_GET['search'];
            $sql = mysqli_query($db,"select * from `card` where title like '%$search%' order by id desc");
            foreach($sql as $row){
            ?>
          <div class="col-md-3">
            <!-- Card box -->
            <div class="card" style="height:350px">
 <div class="card-header">
 <h1 class="card-title"><?php echo $row['title'] ?></h1>   
 </div>
 <div class="card-body">
 <img src="cardImages/<?php echo $row['image'] ?>" class="card-img-top" style="width:100%; height:150px"/>
 <br>
 <p><?php echo $row['description'] ?></p>  
</div>
    <div class="card-footer">
    
    <button class="btn btn-info" data-toggle="modal" data-target="#exampleModal<?php echo $row['id'] ?>">View Details</button>

    
</div>

    </div>

<!-- Modal -->
<div class="modal fade" id="exampleModal<?php echo $row['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
  
    <div class="modal-content">
      <div class="modal-header">
      <img src="cardImages/<?php echo $row['image'] ?>" class="card-img-top" />
  
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <h4><?php echo $row['title'] ?></h4>
        <br>
        <label >Description :</label>
        <p><?php echo $row['description'] ?></p>

        <label >Level :</label>
        <p><?php echo $row['level'] ?></p>
      <div class="modal-footer">
	    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  
  </div>
</div>
 </div>
          </div>
          <?php }}else{
             $sql = mysqli_query($db,"select * from `card` order by id desc");
             foreach($sql as $row){ 
          ?>

<div class="col-md-3">
            <!-- Card box -->
            <div class="card" style="height:350px">
 <div class="card-header">
 <h1 class="card-title"><?php echo $row['title'] ?></h1>   
 </div>
 <div class="card-body">
 <img src="cardImages/<?php echo $row['image'] ?>" class="card-img-top" style="width:100%; height:150px"/>
 <br>
 <p><?php echo $row['description'] ?></p>  
</div>
    <div class="card-footer">
    
    <button class="btn btn-info" data-toggle="modal" data-target="#exampleModal<?php echo $row['id'] ?>">View Details</button>

    
</div>

    </div>

<!-- Modal -->
<div class="modal fade" id="exampleModal<?php echo $row['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
  
    <div class="modal-content">
      <div class="modal-header">
      <img src="cardImages/<?php echo $row['image'] ?>" class="card-img-top" />
  
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <h4><?php echo $row['title'] ?></h4>
        <br>
        <label >Description :</label>
        <p><?php echo $row['description'] ?></p>

        <label >Level :</label>
        <p><?php echo $row['level'] ?></p>
      <div class="modal-footer">
	    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  
  </div>
</div>
 </div>
          </div>

          <?php }}?>


          <!-- <div class="col-lg-3 col-6">
          
            <div class="small-box bg-success">
              <div class="inner">
                <h3>53<sup style="font-size: 20px">%</sup></h3>

                <p>Bounce Rate</p>
              </div>
              <div class="icon">
                <i class="ion ion-stats-bars"></i>
              </div>
              <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          
          <div class="col-lg-3 col-6">
          
            <div class="small-box bg-warning">
              <div class="inner">
                <h3>44</h3>

                <p>User Registrations</p>
              </div>
              <div class="icon">
                <i class="ion ion-person-add"></i>
              </div>
              <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
         
          <div class="col-lg-3 col-6">
          
            <div class="small-box bg-danger">
              <div class="inner">
                <h3>65</h3>

                <p>Unique Visitors</p>
              </div>
              <div class="icon">
                <i class="ion ion-pie-graph"></i>
              </div>
              <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          -->
        </div>
        <!-- /.row -->
      
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php include("footer.php"); ?>